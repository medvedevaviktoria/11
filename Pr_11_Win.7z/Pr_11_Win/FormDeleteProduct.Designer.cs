﻿namespace Pr_11_Win
{
    partial class FormDeleteProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelDeletPrduct = new System.Windows.Forms.Label();
            this.buttonDeleteProduct = new System.Windows.Forms.Button();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.buttonExitAdd = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.listBoxDelete = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // labelDeletPrduct
            // 
            this.labelDeletPrduct.AutoSize = true;
            this.labelDeletPrduct.Location = new System.Drawing.Point(67, 27);
            this.labelDeletPrduct.Name = "labelDeletPrduct";
            this.labelDeletPrduct.Size = new System.Drawing.Size(291, 13);
            this.labelDeletPrduct.TabIndex = 0;
            this.labelDeletPrduct.Text = "Введите id товара, который хотите удалить из корзины:";
            // 
            // buttonDeleteProduct
            // 
            this.buttonDeleteProduct.Enabled = false;
            this.buttonDeleteProduct.Location = new System.Drawing.Point(166, 109);
            this.buttonDeleteProduct.Name = "buttonDeleteProduct";
            this.buttonDeleteProduct.Size = new System.Drawing.Size(75, 23);
            this.buttonDeleteProduct.TabIndex = 1;
            this.buttonDeleteProduct.Text = "Удалить";
            this.buttonDeleteProduct.UseVisualStyleBackColor = true;
            this.buttonDeleteProduct.Click += new System.EventHandler(this.buttonDeleteProduct_Click);
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(152, 70);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 20);
            this.textBoxID.TabIndex = 2;
            this.textBoxID.TextChanged += new System.EventHandler(this.textBoxDeleteProduct_TextChanged);
            this.textBoxID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxDeleteProduct_KeyPress);
            // 
            // buttonExitAdd
            // 
            this.buttonExitAdd.Location = new System.Drawing.Point(325, 353);
            this.buttonExitAdd.Name = "buttonExitAdd";
            this.buttonExitAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonExitAdd.TabIndex = 9;
            this.buttonExitAdd.Text = "Выйти";
            this.buttonExitAdd.UseVisualStyleBackColor = true;
            this.buttonExitAdd.Click += new System.EventHandler(this.buttonExitAdd_Click_1);
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(33, 353);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 23);
            this.buttonBack.TabIndex = 8;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            // 
            // listBoxDelete
            // 
            this.listBoxDelete.FormattingEnabled = true;
            this.listBoxDelete.Location = new System.Drawing.Point(33, 162);
            this.listBoxDelete.Name = "listBoxDelete";
            this.listBoxDelete.Size = new System.Drawing.Size(347, 147);
            this.listBoxDelete.TabIndex = 10;
            // 
            // FormDeleteProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 431);
            this.Controls.Add(this.listBoxDelete);
            this.Controls.Add(this.buttonExitAdd);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.buttonDeleteProduct);
            this.Controls.Add(this.labelDeletPrduct);
            this.Name = "FormDeleteProduct";
            this.Text = "Убрать товар из корзины";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelDeletPrduct;
        private System.Windows.Forms.Button buttonDeleteProduct;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.Button buttonExitAdd;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.ListBox listBoxDelete;
    }
}