﻿namespace Pr_11_Win
{
    partial class FormAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWriteName = new System.Windows.Forms.Label();
            this.labelWritePrice = new System.Windows.Forms.Label();
            this.labelWriteCount = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxCount = new System.Windows.Forms.TextBox();
            this.listBoxAdd = new System.Windows.Forms.ListBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWriteName
            // 
            this.labelWriteName.AutoSize = true;
            this.labelWriteName.Location = new System.Drawing.Point(25, 32);
            this.labelWriteName.Name = "labelWriteName";
            this.labelWriteName.Size = new System.Drawing.Size(141, 13);
            this.labelWriteName.TabIndex = 0;
            this.labelWriteName.Text = "Введите название товара:";
            // 
            // labelWritePrice
            // 
            this.labelWritePrice.AutoSize = true;
            this.labelWritePrice.Location = new System.Drawing.Point(25, 64);
            this.labelWritePrice.Name = "labelWritePrice";
            this.labelWritePrice.Size = new System.Drawing.Size(116, 13);
            this.labelWritePrice.TabIndex = 1;
            this.labelWritePrice.Text = "Введите цену товара:";
            // 
            // labelWriteCount
            // 
            this.labelWriteCount.AutoSize = true;
            this.labelWriteCount.Location = new System.Drawing.Point(25, 96);
            this.labelWriteCount.Name = "labelWriteCount";
            this.labelWriteCount.Size = new System.Drawing.Size(157, 13);
            this.labelWriteCount.TabIndex = 2;
            this.labelWriteCount.Text = "Введите количество товаров:";
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(172, 29);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(208, 20);
            this.textBoxName.TabIndex = 3;
            this.textBoxName.TextChanged += new System.EventHandler(this.textBoxName_TextChanged);
            this.textBoxName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxName_KeyPress);
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(172, 64);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(208, 20);
            this.textBoxPrice.TabIndex = 4;
            this.textBoxPrice.TextChanged += new System.EventHandler(this.textBoxName_TextChanged);
            this.textBoxPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxPrice_KeyPress);
            // 
            // textBoxCount
            // 
            this.textBoxCount.Location = new System.Drawing.Point(188, 96);
            this.textBoxCount.Name = "textBoxCount";
            this.textBoxCount.Size = new System.Drawing.Size(192, 20);
            this.textBoxCount.TabIndex = 5;
            this.textBoxCount.TextChanged += new System.EventHandler(this.textBoxName_TextChanged);
            this.textBoxCount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxCount_KeyPress);
            // 
            // listBoxAdd
            // 
            this.listBoxAdd.FormattingEnabled = true;
            this.listBoxAdd.Location = new System.Drawing.Point(28, 145);
            this.listBoxAdd.Name = "listBoxAdd";
            this.listBoxAdd.Size = new System.Drawing.Size(352, 212);
            this.listBoxAdd.TabIndex = 8;
            // 
            // buttonAdd
            // 
            this.buttonAdd.Enabled = false;
            this.buttonAdd.Location = new System.Drawing.Point(151, 384);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(104, 23);
            this.buttonAdd.TabIndex = 9;
            this.buttonAdd.Text = "Добавить товар";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // FormAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 450);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.listBoxAdd);
            this.Controls.Add(this.textBoxCount);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelWriteCount);
            this.Controls.Add(this.labelWritePrice);
            this.Controls.Add(this.labelWriteName);
            this.Name = "FormAdd";
            this.Text = "Добавить товар в корзину";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelWriteName;
        private System.Windows.Forms.Label labelWritePrice;
        private System.Windows.Forms.Label labelWriteCount;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxCount;
        private System.Windows.Forms.ListBox listBoxAdd;
        private System.Windows.Forms.Button buttonAdd;
    }
}