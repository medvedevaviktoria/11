﻿using Pr_11;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr_11_Win
{
    public partial class FormAdd : Form
    {
        private FormMain formMain;
        public FormAdd()
        {
            InitializeComponent();
           // this.formMain = formMain;
        }
        Product newProduct;
        private void buttonExitAdd_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
           this.Close();
            //formMain.Show();
            //formMain.Focus();
            //this.Hide();
            //Form1 newForm = new Form1();
            ////newForm.Show();
            //Application.Run( Form1());
        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            if ((textBoxName.Text.Length > 0) && (textBoxPrice.Text.Length > 0) && (textBoxCount.Text.Length > 0))
            {
                buttonAdd.Enabled = true;
            }
            else buttonAdd.Enabled = false;
        }

        private void textBoxPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }

            if (Char.IsControl(e.KeyChar))
            {
                return;
            }
            e.Handled = true;
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            e.Handled = !((c >= 'а' && c <= 'я') || c == 'ё' || c == 8 || c == 32);
        }

        private void textBoxCount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }

            if (Char.IsControl(e.KeyChar))
            {
                return;
            }
            e.Handled = true;

        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string  name = Convert.ToString(textBoxName.Text);
            double price = Convert.ToDouble(textBoxPrice.Text);
            int count = Convert.ToInt32(textBoxCount.Text);

            ShoppingCart cart = new ShoppingCart();

            newProduct = new Product(name, price, count);

            cart.AddProduct(newProduct);
            listBoxAdd.Items.Add(newProduct.ShowInfo() + Environment.NewLine);

        }
    }
}
