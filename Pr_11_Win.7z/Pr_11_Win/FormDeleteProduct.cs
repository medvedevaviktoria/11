﻿using Pr_11;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Pr_11_Win
{
    public partial class FormDeleteProduct : Form
    {
        public FormDeleteProduct()
        {
            InitializeComponent();
        }

        private void textBoxDeleteProduct_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }

            if (Char.IsControl(e.KeyChar))
            {
                return;
            }
            e.Handled = true;
        }

        private void textBoxDeleteProduct_TextChanged(object sender, EventArgs e)
        {
            if (textBoxID.Text.Length > 0)
            {
                buttonDeleteProduct.Enabled = true;
            }
            else buttonDeleteProduct.Enabled = false;
        }

        private void buttonExitAdd_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonDeleteProduct_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(textBoxID.Text);
            ShoppingCart cart = new ShoppingCart();

            cart.RemoveProduct(ID);

            listBoxDelete.Items.Add(cart.RemoveProduct(ID) + Environment.NewLine);

        }
    }
}
